
<?php 
 
 require_once 'connect.php';
 
 $response = array();

 $user = array(); 

 // $user  = array(
 // 'date'=>"2017-11-07", 
 // 'people'=>"", 
 // 'clicks'=>"", 
 // 'cost'=>"", 
 // 'conversions'=>"1000", 
 // 'converted_people'=>"", 
 // 'revenue'=>"", 
 // 'linkcost'=>"", 
 
 
 // );


$date_c = $_GET['start'];

$date_cc = $_GET['end'];

  
 
 //$stmt = $conn->prepare("SELECT id,merchant_id,invoice_no,amount,cvv,name,card_no,expiry_month,expiry_year,status,date_c FROM pos WHERE   date_c = ? ");

$stmt = $conn->prepare("SELECT id,merchant_id,invoice_no,amount,tax,name,date_c FROM customer_payment_request where date_c > ? and date_c < ? ");





 

$stmt->bind_param("ss",$date_c,$date_cc);

 $stmt->execute();
 
 $stmt->store_result();
 
 if($stmt->num_rows > 0){
 
 $stmt->bind_result($id,$merchant_id,$invoice_no,$amount,$tax,$name,$date_c);


 while($stmt->fetch()){
 
 $temp  = array(
 'date'=>$date_c, 
 'people'=>$merchant_id, 
 'clicks'=>$invoice_no,
 'cost'=>$tax,
 'Amount'=>$amount, 
 'converted_people'=>$name,
 'revenue'=>"", 
 'linkcost'=>"", 

 
 );
  array_push($user, $temp);
 }


$response = $user; 
}

else
{


$user = array(); 
 
 
 $temp  = array(
 'date'=>$date_c, 
 'people'=>"0", 
 'clicks'=>"0", 
 'cost'=>"0", 
 'Amount'=>"0", 
 'converted_people'=>"0", 
 'revenue'=>"0", 
 'linkcost'=>"0", 

 
 );
  array_push($user, $temp);



$response = $user; 

}








// $sql = "SELECT * FROM customer_payment_request ";
// $result = $conn->query($sql);
 
// if ($result->num_rows > 0) {
//     // output data of each row
//     while($row = $result->fetch_assoc()) {

//        $temp  = array(

//  'date'=>$date_c, 
//  'people'=>$row['merchant_id'], 
//  'clicks'=>$row['invoice_no'],
//  'cost'=>$row['tax'],
//  'conversions'=>$row['amount'], 
//  'converted_people'=>$row['name'],
//  'revenue'=>"", 
//  'linkcost'=>"", 



 
//  );

//     }

// } 
// else {

//      $temp  = array(
       	
//  'date'=>$date_c, 
//  'people'=>"0", 
//  'clicks'=>"0", 
//  'cost'=>"0", 
//  'conversions'=>"0", 
//  'converted_people'=>"0", 
//  'revenue'=>"0", 
//  'linkcost'=>"0", 

 
//  );
// }

//  array_push($user, $temp);

// $response = $user; 


  echo json_encode($response);

 ?>

